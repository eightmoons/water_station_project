<?php 
$servername = "localhost:3306";
$username = "root";
$password = ""; 
$db = "water_station_db";