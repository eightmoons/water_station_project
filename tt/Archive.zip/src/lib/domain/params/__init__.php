<?php

require 'BaseParams.php';
require 'CreateItemParams.php';
require 'CreateProductParams.php';
require 'DeleteItemParams.php';
require 'DeleteProductParams.php';
require 'EditItemParams.php';
require 'EditProductParams.php';
require 'LoadItemListParams.php';
require 'LoadProductListParams.php';
require 'LoginParams.php';
require 'NoParams.php';
require 'ReadUserParams.php';
