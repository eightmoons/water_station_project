<?php

namespace lib\domain\params;

class NoParams extends BaseParams {

}