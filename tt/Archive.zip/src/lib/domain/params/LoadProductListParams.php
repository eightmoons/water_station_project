<?php

namespace lib\domain\params;

class LoadProductListParams extends BaseParams {
    public function __construct(
    ) { }
}