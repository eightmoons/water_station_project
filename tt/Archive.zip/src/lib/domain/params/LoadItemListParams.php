<?php

namespace lib\domain\params;

class LoadItemListParams extends BaseParams
{

}