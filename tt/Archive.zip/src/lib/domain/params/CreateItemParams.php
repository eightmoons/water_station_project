<?php

namespace lib\domain\params;

class CreateItemParams extends BaseParams
{

}