<?php

namespace lib\domain\params;

abstract class BaseParams {

}