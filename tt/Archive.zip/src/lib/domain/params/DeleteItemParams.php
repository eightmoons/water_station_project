<?php

namespace lib\domain\params;

class DeleteItemParams extends BaseParams
{

}