<?php

require 'models/__init__.php';
require 'params/__init__.php';
require 'repository/__init__.php';
require 'usecase/__init__.php';