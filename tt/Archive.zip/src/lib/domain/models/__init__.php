<?php

require 'Item.php';
require 'Product.php';
require 'User.php';