<?php

require 'ItemRepository.php';
require 'ProductRepository.php';
require 'UserRepository.php';