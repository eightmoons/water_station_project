<?php namespace lib\app\widgets;

class HeaderWidget
{
    public function build(): string {
        return <<<Header



Header;

    }
}