<?php

require 'FooterWidget.php';
require 'HeaderWidget.php';
require 'NavBarWidget.php';
require 'ProductWidget.php';