<?php

require 'db/__init__.php';
require 'source/__init__.php';
require 'repository/__init__.php';