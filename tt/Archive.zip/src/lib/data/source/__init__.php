<?php

require 'ProductDao.php';
require 'ProductItemDao.php';
require 'UserDao.php';