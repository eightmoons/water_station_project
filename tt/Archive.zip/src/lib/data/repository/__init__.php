<?php

require 'ProductRepositoryImpl.php';
require 'UserRepositoryImpl.php';
