<?php

require __DIR__ . '/domain/__init__.php';
require __DIR__ . '/data/__init__.php';
require __DIR__ . '/WaterStation.php';
require __DIR__ . '/app/widgets/__init__.php';

